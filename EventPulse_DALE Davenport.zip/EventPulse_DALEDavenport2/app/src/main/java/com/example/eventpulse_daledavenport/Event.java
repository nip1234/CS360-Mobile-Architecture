package com.example.eventpulse_daledavenport;

public class Event {
    private String title;
    private String dateTime;

    public Event(String title, String dateTime) {
        this.title = title;
        this.dateTime = dateTime;
    }

    public String getTitle() {
        return title;
    }

    public String getDateTime() {
        return dateTime;
    }
}