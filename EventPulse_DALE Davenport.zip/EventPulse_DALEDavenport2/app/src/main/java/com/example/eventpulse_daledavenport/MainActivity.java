package com.example.eventpulse_daledavenport;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;
    private RecyclerView recyclerViewEvents;
    private EventAdapter eventAdapter;
    private List<Event> eventList;
    private EventDatabaseHelper dbHelper;
    private FloatingActionButton addEventFab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new EventDatabaseHelper(this);

        checkSmsPermission();
        setupRecyclerView();

        addEventFab = findViewById(R.id.addEventFab);
        addEventFab.setOnClickListener(v -> showAddEventDialog());
    }

    private void setupRecyclerView() {
        recyclerViewEvents = findViewById(R.id.eventsRecyclerView);
        recyclerViewEvents.setLayoutManager(new LinearLayoutManager(this));

        loadEventsFromDatabase();
    }

    private void loadEventsFromDatabase() {
        eventList = new ArrayList<>();
        Cursor cursor = dbHelper.getAllEvents();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndexOrThrow("event_name"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("event_date"));
                eventList.add(new Event(name, date));
            } while (cursor.moveToNext());
            cursor.close();
        }

        eventAdapter = new EventAdapter(eventList);
        recyclerViewEvents.setAdapter(eventAdapter);
    }

    private void showAddEventDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Event");

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);

        final EditText nameInput = new EditText(this);
        nameInput.setHint("Event Name");
        layout.addView(nameInput);

        final EditText dateInput = new EditText(this);
        dateInput.setHint("Date & Time (e.g., Oct 20, 2026)");
        layout.addView(dateInput);

        builder.setView(layout);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String name = nameInput.getText().toString().trim();
            String date = dateInput.getText().toString().trim();

            if (!name.isEmpty() && !date.isEmpty()) {
                boolean success = dbHelper.addEvent(name, date);
                if (success) {
                    Toast.makeText(this, "Event added successfully", Toast.LENGTH_SHORT).show();
                    loadEventsFromDatabase();
                } else {
                    Toast.makeText(this, "Error adding event", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        } else {
            sendEventSms();
        }
    }

    private void sendEventSms() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String phoneNumber = "5551234567";
            String message = "EventPulse Reminder: You have an upcoming event scheduled!";
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Automated SMS notification sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS dispatch failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                sendEventSms();
            } else {
                Toast.makeText(this, "SMS permission denied. Notifications are disabled.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}